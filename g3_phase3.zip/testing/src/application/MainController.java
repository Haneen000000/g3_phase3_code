package application;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class MainController implements Initializable {

    @FXML
    private Button btn_delete;

    @FXML
    private Button btn_insert;

    @FXML
    private Button btn_update;

    @FXML
    private TableColumn<Doctor, String> tv_contactNumber;

    @FXML
    private TableColumn<Doctor, Integer> tv_IDcard;

    @FXML
    private TableView<Doctor> tv_Doctor;

    @FXML
    private TableColumn<Doctor, String> tv_Dname;

    @FXML
    private TextField txt_contactNumber;

    @FXML
    private TextField txt_IDcard;

    @FXML
    private TextField txt_Dname;
    
   
   public void initialize(URL url, ResourceBundle rb) {
        // TODO
	   showDoctor();
    }
   
   public void handleRowSelection(MouseEvent event) {
	   System.out.println("Inside handleRowSelection.");
	    // Get selected row index
	    int index = tv_Doctor.getSelectionModel().getSelectedIndex();
	    System.out.println("Index is :" + index);
	    if (index <= -1) {
	        System.out.println("No row selected.");
	        return;
	    }

	    // Get selected row data from the ObservableList
	    Doctor selectedDoctor = tv_Doctor.getSelectionModel().getSelectedItem();
	    if (selectedDoctor != null) {
	        // Populate text fields with selected row's data
	        txt_IDcard.setText(String.valueOf(selectedDoctor.getIDcard()));
	        txt_Dname.setText(selectedDoctor.getDname());
	        txt_contactNumber.setText(String.valueOf(selectedDoctor.getcontactNumber()));
	    }
	}

   public ObservableList<Doctor> getDoctor(String query) {
	    ObservableList<Doctor> doctorList = FXCollections.observableArrayList();
	    Connection conn = DBConnection.getConnection();

	    Statement st = null; // Initialize st to null
	    ResultSet rs = null; // Initialize rs to null

	    try {
	        st = conn.createStatement();
	        rs = st.executeQuery(query);
	        Doctor doctor;

	        if (!rs.isBeforeFirst()) {
	            System.out.println("No records found for the query: " + query);
	            return null; // Return null if no records found
	        } else {
	            while (rs.next()) {
	                doctor = new Doctor(rs.getInt("IDcard"), rs.getString("Dname"), rs.getString("contactNumber"));
	                doctorList.add(doctor);
	            }
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    } finally {
	        // Close resources in finally block
	        try {
	            if (rs != null) rs.close();
	            if (st != null) st.close();
	            if (conn != null) conn.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return doctorList;
	}

	
    public void showDoctor() {

		String query ="SELECT * FROM db.Doctor";
    	ObservableList<Doctor> doctorList = getDoctor(query);
        // Bind columns with properties
    	tv_IDcard.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getIDcard()).asObject());

    	tv_Dname.setCellValueFactory(new PropertyValueFactory<Doctor, String>("Dname"));
    	tv_contactNumber.setCellValueFactory(new PropertyValueFactory<Doctor, String>("contactNumber"));


        tv_Doctor.setItems(doctorList);
    }
    
  /*  public void insertRecord(){
        String query = "INSERT INTO book.sailors VALUES (" + txt_IDcard.getText() + ",'" + txt_Dname.getText() + "','" + txt_contactNumber.getText() + ")";
        executeQuery(query);
        showDoctor();
    }*/
    public void insertRecord() {
        // Get sid from txt_sid
    	int IDcard = Integer.parseInt(txt_IDcard.getText().trim());

        System.out.println("IDcard: " +IDcard);
        // Check if sid exists
     /*   if (sidExists(sid)) {
            // Handle sid exists case (e.g., show error message)
            System.out.println("SID already exists");
            return;
        }*/
        
        // If sid doesn't exist, proceed with insertion
        String query = "INSERT INTO db.Doctor VALUES ('" + IDcard + "','" + txt_Dname.getText() + "',"
                + txt_contactNumber.getText() + ")";
        executeQuery(query);
        showDoctor();
    }

    private boolean IDcardExists(int IDcard) {
        boolean flag = false;
        String query = "SELECT COUNT(*) FROM db.Doctor WHERE Doctor.IDcard = '" + IDcard + "'";
     
            ObservableList<Doctor> doctorList = getDoctor(query);
            //System.out.println("sailorsList.isEmpty(:)" + !sailorsList.isEmpty());
            if (!doctorList.isEmpty()) {
                // sailorsList is not empty, meaning sid exists
            	 displayAlert("IDcard already exists.");
                System.out.println("IDcard already exists.");
                flag = true;
            }
         
        return flag;
    }
    private void displayAlert(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void updateRecord() {
        String query = "UPDATE db.Doctor SET Dname = '" + txt_Dname.getText() + "', contactNumber = '" + txt_contactNumber.getText() + "' WHERE IDcard = '" + txt_IDcard.getText() + "'";
        executeQuery(query);
        showDoctor();
    }

    


    public void deleteButton(){
        String query = "DELETE FROM db.Doctor WHERE IDcard =" + txt_IDcard.getText() + "";
        executeQuery(query);
        showDoctor();
    }

    public void executeQuery(String query) {
        Connection conn = DBConnection.getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

}