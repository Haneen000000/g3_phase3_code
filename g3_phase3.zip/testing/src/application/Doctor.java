package application;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Doctor {

    private IntegerProperty IDcard;
    private StringProperty Dname;
    private StringProperty contactNumber;

    public Doctor(int IDcard, String Dname, String contactNumber) {
        this.IDcard = new SimpleIntegerProperty(IDcard);
        this.Dname = new SimpleStringProperty(Dname);
        this.contactNumber = new SimpleStringProperty(contactNumber);
    }

    public int getIDcard() {
        return IDcard.get();
    }

    public IntegerProperty IDcardProperty() {
        return IDcard;
    }

    public void setIDcard(int IDcard) {
        this.IDcard.set(IDcard);
    }

    public String getDname() {
        return Dname.get();
    }

    public StringProperty DnameProperty() {
        return Dname;
    }

    public void setDname(String Dname) {
        this.Dname.set(Dname);
    }

    public String getcontactNumber() {
        return contactNumber.get();
    }

    public StringProperty contactNumberProperty() {
        return contactNumber;
    }

    public void setcontactNumber(String contactNumber) {
        this.contactNumber.set(contactNumber);
    }
}